/**
 * Policy do sprawdzania czy użytkownik ma dostęp do produktów danej dostawy
 * Używa tej samej logiki co dostęp do dostawy
 */

export default async (policyContext, config, { strapi }) => {
  const { user } = policyContext.state;
  const { deliveryId } = policyContext.params;

  if (!user || !deliveryId) {
    return false;
  }

  // Admin i staff mogą widzieć wszystkie produkty
  if (user.role?.name === "Admin" || user.role?.name === "Staff") {
    return true;
  }

  // Sprawdź czy użytkownik jest dostawcą
  if (user.role?.name === "Supplier" || user.role?.name === "Dostawca") {
    // Znajdź dostawcę powiązanego z tym użytkownikiem
    const supplier = await strapi.entityService.findMany(
      "api::supplier.supplier",
      {
        filters: {
          email: user.email,
        },
        limit: 1,
      },
    );

    if (!supplier || supplier.length === 0) {
      strapi.log.warn("Supplier not found for user", {
        userId: user.id,
        email: user.email,
      });
      return false;
    }

    // Znajdź dostawę po ID
    const delivery = await strapi.entityService.findMany(
      "api::delivery.delivery",
      {
        filters: {
          id_dostawy: deliveryId,
        },
        fields: ["id_dostawcy"],
        limit: 1,
      },
    );

    if (!delivery || delivery.length === 0) {
      strapi.log.warn("Delivery not found", { deliveryId });
      return false;
    }

    // Sprawdź czy dostawa należy do tego dostawcy
    if (delivery[0].id_dostawcy !== supplier[0].id_dostawcy) {
      strapi.log.warn(
        "Product access denied - delivery belongs to different supplier",
        {
          deliveryId,
          deliverySupplierId: delivery[0].id_dostawcy,
          userSupplierId: supplier[0].id_dostawcy,
        },
      );
      return false;
    }

    return true;
  }

  // Domyślnie odmów dostępu
  return false;
};
