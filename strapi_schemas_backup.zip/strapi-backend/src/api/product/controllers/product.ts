import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::product.product",
  ({ strapi }) => ({
    // Standardowe metody CRUD są automatycznie dostępne

    // Dodatkowa metoda: pobierz produkty z danej dostawy
    async findByDelivery(ctx) {
      const { deliveryId } = ctx.params;

      const products = await strapi.entityService.findMany(
        "api::product.product",
        {
          filters: {
            delivery: {
              id_dostawy: deliveryId,
            },
          },
          populate: {
            delivery: true,
          },
        },
      );

      return this.transformResponse(products);
    },

    // Dodatkowa metoda: pobierz produkty z danej palety w danej dostawie
    async findByDeliveryAndPalette(ctx) {
      const { deliveryId } = ctx.params;

      const products = await strapi.entityService.findMany(
        "api::product.product",
        {
          filters: {
            delivery: {
              id_dostawy: deliveryId,
            },
          },
          populate: {
            delivery: {
              populate: {
                supplier: true,
              },
            },
          },
        },
      );

      return this.transformResponse(products);
    },

    // Dodatkowa metoda: wyszukaj produkty po EAN lub ASIN
    async search(ctx) {
      const { ean, asin, category } = ctx.query;

      interface ProductFilters {
        kod_ean?: { $contains: string };
        kod_asin?: { $contains: string };
        kategoria_produktu?: { $contains: string };
      }

      const filters: ProductFilters = {};

      if (ean) {
        filters.kod_ean = { $contains: ean as string };
      }

      if (asin) {
        filters.kod_asin = { $contains: asin as string };
      }

      if (category) {
        filters.kategoria_produktu = { $contains: category as string };
      }

      const products = await strapi.entityService.findMany(
        "api::product.product",
        {
          filters,
          populate: {
            delivery: {
              populate: {
                supplier: true,
              },
            },
          },
          sort: { createdAt: "desc" },
          pagination: {
            page: ctx.query.page || 1,
            pageSize: ctx.query.pageSize || 25,
          },
        },
      );

      return this.transformResponse(products);
    },

    // Dodatkowa metoda: statystyki produktów
    async stats(ctx) {
      const { deliveryId } = ctx.params;

      // Pobierz wszystkie produkty z dostawy
      const products = await strapi.entityService.findMany(
        "api::product.product",
        {
          filters: {
            delivery: {
              id_dostawy: deliveryId,
            },
          },
        },
      );

      // Oblicz statystyki
      const totalProducts = products.length;
      const totalQuantity = products.reduce(
        (sum, p) => sum + (p.ilosc || 0),
        0,
      );
      const totalValue = products.reduce(
        (sum, p) => sum + (p.cena_produktu_spec || 0) * (p.ilosc || 0),
        0,
      );

      // Grupuj po paletach
      const productsByPalette = {};
      products.forEach((product) => {
        const paletteNumber =
          (product as { palette?: { nr_palety: string } }).palette?.nr_palety ||
          "Brak palety";
        if (!productsByPalette[paletteNumber]) {
          productsByPalette[paletteNumber] = {
            count: 0,
            quantity: 0,
            value: 0,
          };
        }
        productsByPalette[paletteNumber].count++;
        productsByPalette[paletteNumber].quantity += product.ilosc || 0;
        productsByPalette[paletteNumber].value +=
          (product.cena_produktu_spec || 0) * (product.ilosc || 0);
      });

      return {
        deliveryId,
        totalProducts,
        totalQuantity,
        totalValue,
        productsByPalette,
      };
    },
  }),
);
