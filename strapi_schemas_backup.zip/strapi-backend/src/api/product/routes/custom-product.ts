export default {
  routes: [
    {
      method: "GET",
      path: "/products/delivery/:deliveryId",
      handler: "product.findByDelivery",
      config: {
        auth: false,
        policies: ["api::product.check-delivery-product-access"],
        middlewares: ["global::auth-jwt"],
      },
    },
    {
      method: "GET",
      path: "/products/delivery/:deliveryId/palette/:paletteNumber",
      handler: "product.findByDeliveryAndPalette",
      config: {
        auth: false,
        policies: ["api::product.check-delivery-product-access"],
        middlewares: ["global::auth-jwt"],
      },
    },
    {
      method: "GET",
      path: "/products/search",
      handler: "product.search",
      config: {
        auth: false,
        policies: [],
        middlewares: ["global::auth-jwt"],
      },
    },
    {
      method: "GET",
      path: "/products/stats/:deliveryId",
      handler: "product.stats",
      config: {
        auth: false,
        policies: ["api::product.check-delivery-product-access"],
        middlewares: ["global::auth-jwt"],
      },
    },
  ],
};
