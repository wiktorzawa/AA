import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::supplier.supplier",
  ({ strapi }) => ({
    /**
     * Generuje unikalny ID dostawcy
     */
    async generateSupplierId(): Promise<string> {
      const prefix = "SUP";
      const existing = await strapi.entityService.findMany(
        "api::supplier.supplier",
        {
          filters: { id_dostawcy: { $startsWith: prefix } },
          sort: { id_dostawcy: "desc" },
          limit: 1,
        },
      );

      let sequence = 1;
      if (existing && existing.length > 0) {
        const lastId = existing[0].id_dostawcy;
        const lastNumber = parseInt(lastId.split("-")[1]);
        sequence = lastNumber + 1;
      }

      return `${prefix}-${sequence.toString().padStart(4, "0")}`;
    },

    /**
     * Tworzy nowy profil dostawcy oraz powiązane z nim konto użytkownika
     */
    async createWithUser(data: {
      // Wymagane pola z DDL
      nazwa_firmy: string;
      imie_kontaktu: string;
      nazwisko_kontaktu: string;
      numer_nip: string;
      adres_email: string;
      telefon: string;
      adres_ulica: string;
      adres_numer_budynku: string;
      adres_miasto: string;
      adres_kod_pocztowy: string;
      adres_kraj: string;
      // Opcjonalne pola
      password?: string;
      strona_www?: string;
      adres_numer_lokalu?: string;
    }) {
      const supplierId = await this.generateSupplierId();

      const userService = strapi.service("plugin::users-permissions.user");
      const roleService = strapi.service("plugin::users-permissions.role");

      const existingUser = await userService.fetch({ email: data.adres_email });
      if (existingUser) {
        throw new Error(
          `Użytkownik z emailem ${data.adres_email} już istnieje.`,
        );
      }

      const supplierRole = await roleService.findOne({ name: "Supplier" });

      if (!supplierRole) {
        throw new Error(
          "Rola 'Supplier' nie została znaleziona. Upewnij się, że istnieje w systemie.",
        );
      }

      const newUser = await userService.add({
        username: data.adres_email,
        email: data.adres_email,
        password: data.password || Math.random().toString(36).slice(-12),
        role: supplierRole.id,
        provider: "local",
        confirmed: true, // Można ustawić na false i wymagać potwierdzenia
      });

      const supplierProfile = await strapi.entityService.create(
        "api::supplier.supplier",
        {
          data: {
            ...data,
            id_dostawcy: supplierId,
            user: newUser.id,
          },
        },
      );

      return supplierProfile;
    },
  }),
);
