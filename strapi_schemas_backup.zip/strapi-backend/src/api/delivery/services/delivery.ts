/**
 * delivery service
 */

import { factories } from "@strapi/strapi";
import * as fs from "fs";
import excelProcessor from "./excel-processor";
import awsS3Service from "./aws-s3";
import { errors } from "@strapi/utils";

const { ApplicationError } = errors;

export default factories.createCoreService(
  "api::delivery.delivery",
  ({ strapi }) => ({
    // Metoda do przetwarzania przesłanego pliku
    async processUploadedFile(params) {
      const { file, supplierId, confirmDeliveryNumber } = params;

      try {
        // 1. Sprawdź czy AWS S3 jest skonfigurowany
        if (!awsS3Service.isConfigured()) {
          throw new ApplicationError(
            "AWS S3 nie jest skonfigurowany. Sprawdź zmienne środowiskowe.",
          );
        }

        // 2. Parsowanie pliku Excel
        const fileBuffer = fs.readFileSync(file.path);
        const processedData = excelProcessor.processExcelFile(
          fileBuffer,
          file.name,
        );

        // 3. Określ numer lotu (może być null jeśli nie wykryto)
        const finalFlightNumber =
          confirmDeliveryNumber || processedData.deliveryNumber;

        // 4. Sprawdź czy można wygenerować ID dostawy
        const deliveryId = await this.generateDeliveryId(
          finalFlightNumber,
          supplierId,
        );

        if (!deliveryId) {
          // Brak numeru lotu - wymagane uzupełnienie w formularzu
          return {
            requiresFlightNumber: true,
            message:
              "Nie wykryto numeru lotu w nazwie pliku. Proszę uzupełnić w formularzu.",
            processedData: {
              products: processedData.products,
              paletteNumbers: processedData.paletteNumbers,
              totalValue: processedData.totalValue,
              fileName: file.name,
            },
          };
        }

        // 5. Sprawdź czy dostawa już istnieje
        const existingDelivery = await strapi.entityService.findMany(
          "api::delivery.delivery",
          {
            filters: { id_dostawy: deliveryId },
            limit: 1,
          },
        );

        if (existingDelivery && existingDelivery.length > 0) {
          throw new ApplicationError(
            `Dostawa o numerze ${deliveryId} już istnieje`,
          );
        }

        // 6. Znajdź dostawcę
        const suppliers = await strapi.entityService.findMany(
          "api::supplier.supplier",
          {
            filters: { id_dostawcy: supplierId },
            limit: 1,
          },
        );

        if (!suppliers || suppliers.length === 0) {
          throw new ApplicationError("Nie znaleziono dostawcy");
        }
        const supplier = suppliers[0];

        // 7. Upload do S3
        const s3Key = awsS3Service.generateDeliveryFileKey(
          supplierId,
          deliveryId,
          file.name,
        );
        const s3Url = await awsS3Service.uploadFile(fileBuffer, s3Key, {
          originalName: file.name,
          uploadedAt: new Date().toISOString(),
          supplierId,
          deliveryId,
        });

        // 8. Tworzenie dostawy
        const delivery = await strapi.entityService.create(
          "api::delivery.delivery",
          {
            data: {
              id_dostawy: deliveryId,
              id_dostawcy: supplierId,
              id_pliku: this.generateFileId(deliveryId),
              nazwa_pliku: file.name,
              url_pliku_S3: s3Url,
              nr_palet_dostawy: processedData.paletteNumbers.join(", "),
              nr_lot_dostawy: finalFlightNumber, // Numer lotu od dostawcy
              status_weryfikacji: "nowa",
              supplier: supplier.id,
            },
          },
        );

        // 9. Tworzenie produktów
        const products = await this.createProducts(
          processedData.products,
          delivery.id,
        );

        // 10. Automatyczne tworzenie finansów dostawy
        // UWAGA: Dane finansowe będą tworzone później gdy dostawca uzupełni formularz
        // z wymaganymi danymi: kurs_wymiany, procent_wartosci, stawka_vat, waluta
        try {
          strapi.log.info(
            "Pomijam automatyczne tworzenie finansów - wymagane dane od dostawcy",
          );
          // Finanse będą utworzone gdy dostawca uzupełni formularz z:
          // - kurs_wymiany (exchangeRate)
          // - procent_wartosci (marginPercent)
          // - stawka_vat (vatRate)
          // - waluta (currency)
        } catch {
          strapi.log.warn("Informacja o finansach dostawy", {
            deliveryId: delivery.id_dostawy,
            message:
              "Finanse będą utworzone po uzupełnieniu danych przez dostawcę",
          });
        }

        return {
          id_dostawy: delivery.id_dostawy,
          id_dostawcy: supplierId,
          nazwa_pliku: delivery.nazwa_pliku,
          url_pliku_S3: s3Url,
          liczba_produktow: products.length,
          wartosc_calkowita: processedData.totalValue,
          nr_palet_dostawy: processedData.paletteNumbers.join(", "),
          status_weryfikacji: "nowa",
          data_utworzenia: delivery.createdAt,
        };
      } catch (error) {
        strapi.log.error("Błąd przetwarzania pliku:", error);
        if (error instanceof ApplicationError) {
          throw error;
        }
        throw new ApplicationError("Błąd podczas przetwarzania pliku");
      }
    },

    // Podgląd pliku bez zapisywania
    async previewFile(params) {
      strapi.log.info("=== DELIVERY SERVICE - PREVIEW FILE START ===");

      const { file, columnMapping } = params;

      strapi.log.info("Service received params", {
        hasFile: !!file,
        fileName:
          file?.name ||
          file?.originalName ||
          file?.filename ||
          file?.originalFilename,
        fileSize: file?.size,
        fileType: file?.type || file?.mimetype,
        filePath: file?.path || file?.filepath,
        fileKeys: file ? Object.keys(file) : [],
        hasColumnMapping: !!columnMapping,
        columnMapping,
      });

      try {
        strapi.log.info("Service: Reading file buffer");

        // Parsowanie pliku - użyj filepath zamiast path
        const filePath = file.path || file.filepath;

        if (!filePath) {
          throw new ApplicationError("Brak ścieżki do pliku");
        }

        strapi.log.info("Service: File path", { filePath });

        const fileBuffer = fs.readFileSync(filePath);

        strapi.log.info("Service: File buffer read successfully", {
          bufferSize: fileBuffer.length,
          bufferType: typeof fileBuffer,
        });

        strapi.log.info("Service: Calling excel processor");

        const processedData = excelProcessor.processExcelFile(
          fileBuffer,
          file.name ||
            file.originalName ||
            file.filename ||
            file.originalFilename,
        );

        strapi.log.info("Service: Excel processing completed", {
          hasDeliveryNumber: !!processedData.deliveryNumber,
          deliveryNumber: processedData.deliveryNumber,
          productsCount: processedData.products.length,
          paletteCount: processedData.paletteNumbers.length,
          totalValue: processedData.totalValue,
          hasHeaders: processedData.hasHeaders,
        });

        // Określ status analizy
        let analysisStatus = "WYMAGA_DANYCH_FINANSOWYCH";
        const warnings = [];

        // Sprawdź czy można wygenerować ID dostawy
        const canGenerateId = excelProcessor.generateDeliveryId(
          processedData.deliveryNumber,
        );

        if (!canGenerateId) {
          analysisStatus = "WYMAGA_NUMERU_LOTU";
          warnings.push(
            "Nie wykryto numeru lotu w nazwie pliku - wymagane uzupełnienie",
          );
        } else if (!processedData.deliveryNumber) {
          warnings.push("Nie wykryto numeru lotu w nazwie pliku");
          analysisStatus = "WYMAGA_POTWIERDZENIA";
        }

        if (processedData.products.length === 0) {
          analysisStatus = "BŁĄD";
          warnings.push("Brak produktów w pliku");
        }

        // Jeśli nie wykryto nagłówków lub używamy fallback mapowania, wymagaj mapowania
        if (
          !processedData.hasHeaders &&
          analysisStatus !== "WYMAGA_NUMERU_LOTU"
        ) {
          analysisStatus = "WYMAGA_MAPOWANIA";
          warnings.push("Nie wykryto nagłówków kolumn - sprawdź mapowanie");
        }

        // Zawsze wymagaj danych finansowych od dostawcy
        if (
          analysisStatus === "SUKCES" ||
          analysisStatus === "WYMAGA_POTWIERDZENIA"
        ) {
          analysisStatus = "WYMAGA_DANYCH_FINANSOWYCH";
          warnings.push(
            "Wymagane uzupełnienie danych finansowych: kurs wymiany, marża, VAT, waluta",
          );
        }

        strapi.log.info("Service: Analysis completed", {
          analysisStatus,
          warningsCount: warnings.length,
          warnings,
        });

        const result = {
          analysisStatus,
          products: processedData.products,
          availableColumns: processedData.headers || [], // Używaj headers z processedData
          columnMapping: processedData.columnMapping,
          deliveryNumber: processedData.deliveryNumber,
          paletteNumbers: processedData.paletteNumbers,
          totalProducts: processedData.products.length,
          estimatedValue: processedData.totalValue,
          fileName:
            file.name ||
            file.originalName ||
            file.filename ||
            file.originalFilename,
          hasHeaders: processedData.hasHeaders,
          productSample: processedData.products.slice(0, 5),
          validationWarnings: warnings,
        };

        strapi.log.info(
          "=== DELIVERY SERVICE - PREVIEW FILE END - SUCCESS ===",
        );

        return result;
      } catch (error) {
        strapi.log.error(
          "=== DELIVERY SERVICE - PREVIEW FILE END - ERROR ===",
          {
            errorMessage: error.message,
            errorStack: error.stack,
            errorName: error.name,
            filePath: file?.path || file?.filepath,
            fileName:
              file?.name ||
              file?.originalName ||
              file?.filename ||
              file?.originalFilename,
          },
        );

        if (error instanceof ApplicationError) {
          throw error;
        }
        throw new ApplicationError("Błąd podczas tworzenia podglądu pliku");
      }
    },

    // Generowanie ID pliku
    generateFileId(deliveryId) {
      return `F${deliveryId}`;
    },

    async generateDeliveryId(lotNumber, supplierId) {
      if (!lotNumber || !supplierId) {
        return null;
      }
      const count = await strapi.db
        .query("api::delivery.delivery")
        .count({ where: { id_dostawcy: supplierId } });

      const sequence = String(count + 1).padStart(3, "0");
      return `DOST/${lotNumber}/${sequence}`;
    },

    // Tworzenie produktów
    async createProducts(productsData, deliveryId) {
      const products = [];

      const asinQuantities = productsData.reduce((acc, product) => {
        if (product.kod_asin) {
          acc[product.kod_asin] =
            (acc[product.kod_asin] || 0) + (Number(product.ilosc) || 0);
        }
        return acc;
      }, {});

      for (const productData of productsData) {
        const randomNumber = Math.random().toString().slice(2, 10);
        const totalQuantity = productData.kod_asin
          ? asinQuantities[productData.kod_asin]
          : Number(productData.ilosc) || 1;

        let id_produktu = `PROD/${randomNumber}`;
        if (totalQuantity > 1) {
          id_produktu += `/${totalQuantity}`;
        }

        const product = await strapi.entityService.create(
          "api::product.product",
          {
            data: {
              id_produktu: id_produktu,
              nazwa_produktu: productData.nazwa_produktu,
              kod_ean: productData.kod_ean,
              kod_asin: productData.kod_asin,
              lpn: productData.LPN,
              ilosc: Number(productData.ilosc) || 0,
              cena_produktu_spec: Number(productData.cena_produktu_spec) || 0,
              stan_produktu: String(productData.stan_produktu || "nowy"),
              kraj_pochodzenia: productData.kraj_pochodzenia,
              kategoria_produktu: productData.kategoria_produktu,
              delivery: deliveryId,
              nr_palety: productData.nr_palety
                ? String(productData.nr_palety)
                : null,
            },
          },
        );
        products.push(product);
      }

      return products;
    },

    // Potwierdź i zapisz dostawę
    async confirmAndSaveDelivery(params) {
      const { file, supplierId, confirmationData } = params;

      try {
        // Podobna logika jak processUploadedFile, ale z dodatkowymi potwierdzeniami
        const fileBuffer = fs.readFileSync(file.path);
        const processedData = excelProcessor.processExcelFile(
          fileBuffer,
          file.name,
        );

        // Użyj potwierdzonego numeru lotu jeśli dostępny
        const finalFlightNumber =
          confirmationData.confirmedDeliveryNumber ||
          processedData.deliveryNumber;

        // Generuj ID dostawy (może być automatyczny jeśli brak numeru lotu)
        const deliveryId = await this.generateDeliveryId(
          finalFlightNumber,
          supplierId,
        );

        // Sprawdź czy dostawa już istnieje
        const existingDelivery = await strapi.entityService.findMany(
          "api::delivery.delivery",
          {
            filters: { id_dostawy: deliveryId },
            limit: 1,
          },
        );

        if (existingDelivery && existingDelivery.length > 0) {
          throw new ApplicationError(
            `Dostawa o numerze ${deliveryId} już istnieje`,
          );
        }

        // Znajdź dostawcę
        const supplier = await strapi.entityService.findMany(
          "api::supplier.supplier",
          {
            filters: { id_dostawcy: supplierId },
            limit: 1,
          },
        );

        if (!supplier || supplier.length === 0) {
          throw new ApplicationError("Nie znaleziono dostawcy");
        }

        // Zastosuj poprawki produktów jeśli są
        const products = [...processedData.products];
        if (confirmationData.productCorrections) {
          confirmationData.productCorrections.forEach((correction) => {
            if (correction.index < products.length) {
              products[correction.index] = {
                ...products[correction.index],
                ...correction.corrections,
              };
            }
          });
        }

        // Upload do S3
        const s3Key = awsS3Service.generateDeliveryFileKey(
          supplierId,
          deliveryId,
          file.name,
        );
        const s3Url = await awsS3Service.uploadFile(fileBuffer, s3Key, {
          originalName: file.name,
          uploadedAt: new Date().toISOString(),
          supplierId,
          deliveryId,
        });

        // Użyj potwierdzonych numerów palet jeśli dostępne
        const finalPaletteNumbers =
          confirmationData.confirmedPaletteNumbers ||
          processedData.paletteNumbers;

        // Tworzenie dostawy
        const delivery = await strapi.entityService.create(
          "api::delivery.delivery",
          {
            data: {
              id_dostawy: deliveryId,
              id_dostawcy: supplierId,
              id_pliku: this.generateFileId(deliveryId),
              nazwa_pliku: file.name,
              url_pliku_S3: s3Url,
              nr_palet_dostawy: finalPaletteNumbers.join(", "),
              nr_lot_dostawy: finalFlightNumber, // Numer lotu od dostawcy
              status_weryfikacji: "nowa",
              supplier: supplier[0].id,
            },
          },
        );

        // Tworzenie produktów z poprawkami
        const savedProducts = await this.createProducts(products, delivery.id);

        // Automatyczne tworzenie finansów dostawy
        // UWAGA: Dane finansowe będą tworzone później gdy dostawca uzupełni formularz
        // z wymaganymi danymi: kurs_wymiany, procent_wartosci, stawka_vat, waluta
        try {
          strapi.log.info(
            "Pomijam automatyczne tworzenie finansów - wymagane dane od dostawcy",
          );
          // Finanse będą utworzone gdy dostawca uzupełni formularz z:
          // - kurs_wymiany (exchangeRate)
          // - procent_wartosci (marginPercent)
          // - stawka_vat (vatRate)
          // - waluta (currency)
        } catch {
          strapi.log.warn("Informacja o finansach dostawy", {
            deliveryId: delivery.id_dostawy,
            message:
              "Finanse będą utworzone po uzupełnieniu danych przez dostawcę",
          });
        }

        // Oblicz wartość całkowitą
        const totalValue = products.reduce(
          (sum, product) =>
            sum + (product.cena_produktu_spec || 0) * product.ilosc,
          0,
        );

        return {
          id_dostawy: delivery.id_dostawy,
          id_dostawcy: supplierId,
          nazwa_pliku: delivery.nazwa_pliku,
          url_pliku_S3: s3Url,
          liczba_produktow: savedProducts.length,
          wartosc_calkowita: totalValue,
          nr_palet_dostawy: finalPaletteNumbers.join(", "),
          status_weryfikacji: "nowa",
          data_utworzenia: delivery.createdAt,
          validationSummary: {
            appliedCorrections:
              confirmationData.productCorrections?.length || 0,
            bypassedValidation: confirmationData.bypassValidation || false,
          },
        };
      } catch (error) {
        strapi.log.error("Błąd podczas potwierdzania dostawy:", error);
        if (error instanceof ApplicationError) {
          throw error;
        }
        throw new ApplicationError("Błąd podczas potwierdzania dostawy");
      }
    },

    async analyzeDelivery(deliveryId) {
      strapi.log.info(`Service: Analyzing delivery with ID: ${deliveryId}`);

      const delivery = await strapi.entityService.findOne(
        "api::delivery.delivery",
        deliveryId,
        {
          populate: {
            supplier: true,
            products: true,
          },
        },
      );

      if (!delivery) {
        return null;
      }

      // Definicje typów dla poprawy czytelności
      type ProductWithPalette = {
        nr_palety?: string;
        ilosc?: number;
        cena_produktu_spec?: number;
        nazwa_produktu?: string;
        kod_ean?: string;
        kod_asin?: string;
      };

      type DeliveryWithProducts = {
        products?: ProductWithPalette[];
        id_dostawy?: string;
        nazwa_pliku?: string;
        status_weryfikacji?: string;
        supplier?: unknown;
        createdAt?: string;
        updatedAt?: string;
      };

      const deliveryTyped = delivery as DeliveryWithProducts;

      // Analiza produktów
      const productStats: {
        total: number;
        byStatus: Record<string, number>;
        byPalette: Record<
          string,
          {
            count: number;
            quantity: number;
            value: number;
            products: {
              nazwa?: string;
              ean?: string;
              asin?: string;
              ilosc?: number;
              cena?: number;
            }[];
          }
        >;
        totalValue: number;
        totalQuantity: number;
      } = {
        total: deliveryTyped.products?.length || 0,
        byStatus: {},
        byPalette: {},
        totalValue: 0,
        totalQuantity: 0,
      };

      deliveryTyped.products?.forEach((product) => {
        // Statystyki po statusie
        const status = (product as any).status_weryfikacji || "brak";
        productStats.byStatus[status] =
          (productStats.byStatus[status] || 0) + 1;

        // Statystyki po palecie
        const paletteNumber = product.nr_palety || "Brak palety";
        if (!productStats.byPalette[paletteNumber]) {
          productStats.byPalette[paletteNumber] = {
            count: 0,
            quantity: 0,
            value: 0,
            products: [],
          };
        }
        productStats.byPalette[paletteNumber].count++;
        productStats.byPalette[paletteNumber].quantity += product.ilosc || 0;
        productStats.byPalette[paletteNumber].value +=
          (product.cena_produktu_spec || 0) * (product.ilosc || 0);
        productStats.byPalette[paletteNumber].products.push({
          nazwa: product.nazwa_produktu,
          ean: product.kod_ean,
          asin: product.kod_asin,
          ilosc: product.ilosc,
          cena: product.cena_produktu_spec,
        });

        // Totale
        productStats.totalQuantity += product.ilosc || 0;
        productStats.totalValue +=
          (product.cena_produktu_spec || 0) * (product.ilosc || 0);
      });

      const paletteCount = new Set(
        deliveryTyped.products.map((p) => p.nr_palety).filter(Boolean),
      ).size;

      return {
        delivery: {
          id_dostawy: deliveryTyped.id_dostawy,
          nazwa_pliku: deliveryTyped.nazwa_pliku,
          status_weryfikacji: deliveryTyped.status_weryfikacji,
          supplier: deliveryTyped.supplier,
        },
        analysis: {
          productStats,
          paletteCount: paletteCount,
          createdAt: deliveryTyped.createdAt,
          updatedAt: deliveryTyped.updatedAt,
        },
      };
    },

    async getFullDeliveryDetails(deliveryId) {
      try {
        const delivery = await strapi.entityService.findOne(
          "api::delivery.delivery",
          deliveryId,
          {
            populate: ["supplier", "products"],
          },
        );
        if (!delivery) {
          throw new ApplicationError("Nie znaleziono dostawy");
        }
        return delivery;
      } catch (error) {
        strapi.log.error(
          `Błąd pobierania pełnych szczegółów dostawy ${deliveryId}`,
          error,
        );
        throw new ApplicationError(
          "Błąd podczas pobierania szczegółów dostawy",
        );
      }
    },
  }),
);
