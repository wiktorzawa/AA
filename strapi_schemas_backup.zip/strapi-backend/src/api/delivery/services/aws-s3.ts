import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { errors } from "@strapi/utils";

const { ApplicationError } = errors;

export class AwsS3Service {
  private s3Client: S3Client;
  private bucketName: string;

  constructor() {
    this.bucketName = process.env.AWS_BUCKET_NAME || "msbox-deliveries";

    this.s3Client = new S3Client({
      region: process.env.AWS_REGION || "us-east-1",
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
      },
    });
  }

  /**
   * Upload pliku do S3
   */
  async uploadFile(
    fileBuffer: Buffer,
    key: string,
    metadata?: Record<string, string>,
  ): Promise<string> {
    try {
      const command = new PutObjectCommand({
        Bucket: this.bucketName,
        Key: key,
        Body: fileBuffer,
        ContentType: "application/octet-stream",
        Metadata: metadata || {},
      });

      await this.s3Client.send(command);

      const fileUrl = `https://${this.bucketName}.s3.${process.env.AWS_REGION || "us-east-1"}.amazonaws.com/${key}`;

      strapi.log.info("File uploaded to S3", { key, url: fileUrl });

      return fileUrl;
    } catch (error) {
      strapi.log.error("Error uploading file to S3", { error, key });
      throw new ApplicationError("Błąd podczas przesyłania pliku do S3");
    }
  }

  /**
   * Pobierz plik z S3
   */
  async getFile(key: string) {
    try {
      const command = new GetObjectCommand({
        Bucket: this.bucketName,
        Key: key,
      });

      const response = await this.s3Client.send(command);
      return response;
    } catch (error) {
      strapi.log.error("Error getting file from S3", { error, key });
      throw new ApplicationError("Błąd podczas pobierania pliku z S3");
    }
  }

  /**
   * Generuje klucz S3 dla pliku dostawy
   */
  generateDeliveryFileKey(
    supplierId: string,
    deliveryId: string,
    fileName: string,
  ): string {
    const timestamp = Date.now();
    const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, "_");
    return `deliveries/${supplierId}/${deliveryId}/${timestamp}-${sanitizedFileName}`;
  }

  /**
   * Sprawdza czy bucket jest skonfigurowany
   */
  isConfigured(): boolean {
    return !!(
      process.env.AWS_ACCESS_KEY_ID &&
      process.env.AWS_SECRET_ACCESS_KEY &&
      process.env.AWS_BUCKET_NAME
    );
  }
}

export default new AwsS3Service();
