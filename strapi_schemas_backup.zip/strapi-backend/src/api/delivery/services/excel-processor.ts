import * as XLSX from "xlsx";
import { errors } from "@strapi/utils";

const { ApplicationError } = errors;

export interface ProcessedProduct {
  nr_palety: string;
  LPN: string;
  kod_ean: string;
  kod_asin: string;
  nazwa_produktu: string;
  ilosc: number;
  cena_produktu_spec: number;
  stan_produktu: string;
  kraj_pochodzenia: string;
  kategoria_produktu?: string;
}

export interface ProcessedExcelData {
  deliveryNumber: string | null;
  products: ProcessedProduct[];
  paletteNumbers: string[];
  totalValue: number;
  hasHeaders: boolean;
  columnMapping: ColumnMapping;
  headers: string[]; // Dodaj headers
}

export interface ColumnMapping {
  productName?: number;
  quantity?: number;
  price?: number;
  ean?: number;
  asin?: number;
  lpn?: number;
  palette?: number;
  condition?: number;
  country?: number;
  category?: number;
}

export class ExcelProcessorService {
  /**
   * Przetwarza plik Excel i wyciąga dane produktów
   */
  processExcelFile(fileBuffer: Buffer, fileName: string): ProcessedExcelData {
    strapi.log.info("=== EXCEL PROCESSOR - START ===");

    try {
      strapi.log.info("Excel processor: Input data", {
        fileName,
        bufferSize: fileBuffer.length,
        fileExtension: fileName
          ? fileName.slice(fileName.lastIndexOf(".")).toLowerCase()
          : "unknown",
      });

      // 1. Wczytaj plik Excel
      strapi.log.info("Excel processor: Reading workbook");

      const workbook = XLSX.read(fileBuffer, {
        type: "buffer",
        cellNF: true,
        cellDates: true,
        raw: true,
      });

      strapi.log.info("Excel processor: Workbook read successfully", {
        sheetNames: workbook.SheetNames,
        sheetCount: workbook.SheetNames.length,
      });

      // 2. Pobierz pierwszy arkusz
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];

      if (!worksheet) {
        strapi.log.error("Excel processor: Worksheet is empty or undefined");
        throw new ApplicationError(
          "Plik Excel jest pusty lub nie zawiera danych",
        );
      }

      strapi.log.info("Excel processor: Worksheet selected", {
        sheetName,
        worksheetKeys: Object.keys(worksheet).length,
      });

      // 3. Konwertuj do JSON
      strapi.log.info("Excel processor: Converting to JSON");

      const jsonData = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: "",
        blankrows: false,
      }) as (string | number)[][];

      strapi.log.info("Excel processor: JSON conversion completed", {
        totalRows: jsonData.length,
        firstRowData: jsonData[0] || [],
        firstRowLength: jsonData[0]?.length || 0,
      });

      if (jsonData.length === 0) {
        strapi.log.error("Excel processor: No data in JSON result");
        throw new ApplicationError("Plik Excel jest pusty");
      }

      // 4. Wykryj nagłówki i mapowanie kolumn
      strapi.log.info("Excel processor: Detecting headers");

      const { hasHeaders, headers, columnMapping } =
        this.detectAndMapHeaders(jsonData);

      strapi.log.info("Excel processor: Headers detection completed", {
        hasHeaders,
        headersCount: headers.length,
        headers: headers.slice(0, 10), // Pokaż pierwsze 10 nagłówków
        columnMapping,
        firstFewRows: jsonData.slice(0, 3), // Pokaż pierwsze 3 wiersze
      });

      const dataRows = hasHeaders ? jsonData.slice(1) : jsonData;

      strapi.log.info("Excel processor: Data rows prepared", {
        totalDataRows: dataRows.length,
        skippedHeaderRow: hasHeaders,
      });

      if (dataRows.length === 0) {
        strapi.log.error(
          "Excel processor: No data rows after header processing",
        );
        throw new ApplicationError("Brak danych do przetworzenia w pliku");
      }

      // 5. Wyodrębnij numer dostawy z nazwy pliku
      strapi.log.info("Excel processor: Extracting delivery number");

      // Wykryj numer lotu z nazwy pliku
      const detectedFlightNumber = this.detectFlightNumber(fileName);

      console.log("🔥 WYKRYTY NUMER LOTU:", {
        fileName,
        detectedFlightNumber,
      });

      // 6. Przetwórz produkty
      strapi.log.info("Excel processor: Processing products");

      const products: ProcessedProduct[] = [];
      const paletteNumbers = new Set<string>();
      let totalValue = 0;

      for (let i = 0; i < dataRows.length; i++) {
        const row = dataRows[i];
        if (!row || row.length === 0 || row.every((cell) => cell === ""))
          continue;

        const product = this.mapRowToProduct(row, headers, columnMapping);
        if (product) {
          products.push(product);
          if (product.nr_palety) {
            paletteNumbers.add(product.nr_palety);
          }
          if (product.cena_produktu_spec && product.ilosc) {
            totalValue += product.cena_produktu_spec * product.ilosc;
          }
        } else {
          strapi.log.warn("Excel processor: Skipped invalid row", {
            rowIndex: i,
            rowData: row,
          });
        }
      }

      strapi.log.info("Excel processor: Products processing completed", {
        totalProducts: products.length,
        uniquePalettes: paletteNumbers.size,
        totalValue,
        paletteNumbers: Array.from(paletteNumbers),
      });

      const result = {
        deliveryNumber: detectedFlightNumber, // Zachowuję nazwę dla kompatybilności
        products,
        paletteNumbers: Array.from(paletteNumbers),
        totalValue,
        hasHeaders,
        columnMapping,
        headers, // Dodaj headers dla frontend
      };

      strapi.log.info("=== EXCEL PROCESSOR - END - SUCCESS ===");

      return result;
    } catch (error) {
      strapi.log.error("=== EXCEL PROCESSOR - END - ERROR ===", {
        errorMessage: error.message,
        errorStack: error.stack,
        errorName: error.name,
        fileName,
        bufferSize: fileBuffer?.length,
      });

      if (error instanceof ApplicationError) {
        throw error;
      }
      strapi.log.error("Excel processor: Unexpected error", { error });
      throw new ApplicationError("Nie można przetworzyć pliku Excel");
    }
  }

  /**
   * Wykrywa nagłówki i mapuje kolumny
   */
  private detectAndMapHeaders(data: (string | number)[][]) {
    if (data.length === 0) {
      return { hasHeaders: false, headers: [], columnMapping: {} };
    }

    const firstRow = data[0];
    const headers = firstRow.map((cell) => String(cell).toLowerCase().trim());

    console.log("🔥 HEADERS DETECTION:", {
      firstRow: firstRow,
      headers: headers,
      firstRowLength: firstRow.length,
    });

    // Funkcja pomocnicza do znajdowania kolumny na podstawie możliwych nazw
    const findColumnIndex = (possibleNames: string[]): number => {
      for (const name of possibleNames) {
        const index = headers.findIndex((header) =>
          header.includes(name.toLowerCase()),
        );
        if (index !== -1) return index;
      }
      return -1;
    };

    // Mapowanie kolumn na podstawie nazw nagłówków (obsługa różnych wariantów)
    const columnMapping: ColumnMapping = {
      // Nazwa produktu - różne warianty
      productName: findColumnIndex([
        "item desc",
        "item description",
        "product name",
        "nazwa produktu",
        "nazwa",
        "produkt",
        "description",
        "desc",
        "name",
      ]),

      // Ilość - różne warianty
      quantity: findColumnIndex([
        "quantity",
        "qty",
        "ilość",
        "ilosc",
        "sztuki",
        "szt",
        "amount",
        "count",
      ]),

      // Cena - różne warianty
      price: findColumnIndex([
        "unit retail",
        "price",
        "cena",
        "unit price",
        "cost",
        "retail",
        "unit cost",
        "cena jednostkowa",
      ]),

      // EAN - kod kreskowy
      ean: findColumnIndex([
        "ean",
        "ean13",
        "barcode",
        "kod kreskowy",
        "kod ean",
      ]),

      // ASIN - kod Amazon
      asin: findColumnIndex(["asin", "amazon asin", "kod asin"]),

      // LPN - numer logistyczny
      lpn: findColumnIndex([
        "lpn",
        "license plate number",
        "numer lpn",
        "lpn number",
      ]),

      // Paleta - numer palety
      palette: findColumnIndex([
        "nr palety",
        "paleta",
        "palette",
        "pallet",
        "pallet number",
        "numer palety",
        "nr palet",
      ]),

      // Stan produktu
      condition: findColumnIndex([
        "stan",
        "condition",
        "state",
        "status",
        "stan produktu",
      ]),

      // Kraj pochodzenia
      country: findColumnIndex([
        "kraj",
        "country",
        "origin",
        "kraj pochodzenia",
        "pochodzenie",
      ]),

      // Kategoria
      category: findColumnIndex([
        "kategoria",
        "category",
        "cat",
        "typ",
        "type",
        "grupa",
      ]),
    };

    console.log("🔥 COLUMN MAPPING WYNIK:", {
      columnMapping: columnMapping,
      productNameIndex: columnMapping.productName,
      quantityIndex: columnMapping.quantity,
      priceIndex: columnMapping.price,
      paletteIndex: columnMapping.palette,
    });

    // Sprawdź czy znaleziono przynajmniej podstawowe kolumny
    const hasBasicColumns =
      columnMapping.productName !== -1 ||
      columnMapping.ean !== -1 ||
      columnMapping.asin !== -1;

    if (!hasBasicColumns) {
      console.log("🔥 BRAK PODSTAWOWYCH KOLUMN - UŻYWAM FALLBACK MAPOWANIA");
      // Fallback - jeśli nie ma rozpoznawalnych nagłówków,
      // użyj pierwszego wiersza jako danych i domyślnego mapowania
      return {
        hasHeaders: false,
        headers: firstRow.map((_, i) => `Kolumna ${i + 1}`),
        columnMapping: {
          palette: 0, // Pierwsza kolumna = paleta
          productName: 1, // Druga kolumna = nazwa produktu
          ean: 2, // Trzecia kolumna = EAN
          asin: 3, // Czwarta kolumna = ASIN
          condition: 4, // Piąta kolumna = stan
          country: 5, // Szósta kolumna = kraj
          price: 6, // Siódma kolumna = cena
          quantity: -1, // Brak kolumny ilości
          lpn: -1,
          category: -1,
        },
      };
    }

    console.log(
      "🔥 ZNALEZIONO NAGŁÓWKI - UŻYWAM MAPOWANIA OPARTEGO NA NAZWACH",
    );
    return {
      hasHeaders: true,
      headers: firstRow.map((h) => String(h)),
      columnMapping,
    };
  }

  /**
   * Mapuje wiersz danych na produkt
   */
  private mapRowToProduct(
    row: (string | number)[],
    headers: string[],
    mapping: ColumnMapping,
  ): ProcessedProduct | null {
    // DODAJ PROSTE LOGI DEBUGUJĄCE
    console.log("🔥 PIERWSZY WIERSZ DEBUG:", {
      row: row,
      mapping: mapping,
      mappingProductName: mapping.productName,
      mappingQuantity: mapping.quantity,
      productNameColumn:
        mapping.productName >= 0 ? row[mapping.productName] : "BRAK_INDEKSU",
      quantityColumn:
        mapping.quantity >= 0 ? row[mapping.quantity] : "BRAK_INDEKSU",
    });

    strapi.log.error("DEBUG: Mapping row to product:", {
      row: row.slice(0, 5), // Pokaż pierwsze 5 kolumn
      mapping,
      rowLength: row.length,
    });

    // Nazwa produktu jest wymagana
    const productName =
      mapping.productName !== undefined && mapping.productName >= 0
        ? row[mapping.productName]?.toString().trim()
        : "";

    // Ilość - jeśli brak kolumny quantity w pliku dostawcy, automatycznie ustaw 1
    let quantity = 1; // Domyślna wartość
    let quantitySource = "DOMYŚLNA (brak kolumny)";

    if (mapping.quantity !== undefined && mapping.quantity >= 0) {
      const parsedQuantity = this.parseNumber(row[mapping.quantity]);
      if (parsedQuantity > 0) {
        quantity = parsedQuantity;
        quantitySource = "Z_KOLUMNY";
      } else {
        quantitySource = "DOMYŚLNA (wartość 0 lub błędna)";
      }
    }

    console.log("🔥 DRUGI LOG DEBUG:", {
      productName: productName,
      quantity: quantity,
      quantitySource: quantitySource,
      productNameEmpty: !productName,
      hasQuantityColumn: mapping.quantity >= 0,
      quantityColumnValue:
        mapping.quantity >= 0 ? row[mapping.quantity] : "BRAK_KOLUMNY",
    });

    strapi.log.error("DEBUG: Product validation check:", {
      productName,
      quantity,
      productNameValid: !!productName,
      quantityValid: quantity > 0,
      productNameIndex: mapping.productName,
      quantityIndex: mapping.quantity,
      actualProductNameValue:
        mapping.productName >= 0 ? row[mapping.productName] : "INDEX_NOT_FOUND",
      actualQuantityValue:
        mapping.quantity >= 0 ? row[mapping.quantity] : "DEFAULT_1",
    });

    // Tylko nazwa produktu jest wymagana, ilość ma domyślną wartość
    if (!productName) {
      console.log("🔥 ODRZUCONY:", {
        productName,
        quantity,
        reason: "brak nazwy produktu",
      });
      strapi.log.error("DEBUG: Row rejected:", {
        reason: "No product name",
        productName,
        quantity,
      });
      return null;
    }

    const result = {
      nr_palety:
        mapping.palette !== undefined && mapping.palette >= 0
          ? row[mapping.palette]?.toString().trim() || "1"
          : "1",
      LPN:
        mapping.lpn !== undefined && mapping.lpn >= 0
          ? row[mapping.lpn]?.toString().trim() || ""
          : "",
      kod_ean:
        mapping.ean !== undefined && mapping.ean >= 0
          ? row[mapping.ean]?.toString().trim() || ""
          : "",
      kod_asin:
        mapping.asin !== undefined && mapping.asin >= 0
          ? row[mapping.asin]?.toString().trim() || ""
          : "",
      nazwa_produktu: productName,
      ilosc: quantity,
      cena_produktu_spec:
        mapping.price !== undefined && mapping.price >= 0
          ? this.parseNumber(row[mapping.price]) || 0
          : 0,
      stan_produktu:
        mapping.condition !== undefined && mapping.condition >= 0
          ? row[mapping.condition]?.toString().trim() || "new"
          : "new",
      kraj_pochodzenia:
        mapping.country !== undefined && mapping.country >= 0
          ? row[mapping.country]?.toString().trim() || "unknown"
          : "unknown",
      kategoria_produktu:
        mapping.category !== undefined && mapping.category >= 0
          ? row[mapping.category]?.toString().trim() || undefined
          : undefined,
    };

    strapi.log.error("DEBUG: Product created successfully:", result);
    return result;
  }

  /**
   * Parsuje wartość na liczbę, obsługując różne formaty
   */
  private parseNumber(value: string | number): number {
    if (typeof value === "number") {
      return value;
    }
    if (!value) return 0;

    const cleaned = value
      .toString()
      .replace(/[^\d,.-]/g, "")
      .replace(",", ".");

    return parseFloat(cleaned) || 0;
  }

  /**
   * Wykrywa numer lotu z nazwy pliku
   */
  private detectFlightNumber(fileName: string): string | null {
    // Usuń rozszerzenie pliku
    const nameWithoutExt = fileName.replace(/\.[^/.]+$/, "");

    console.log("🔥 WYKRYWANIE NUMERU LOTU:", {
      originalFileName: fileName,
      nameWithoutExt: nameWithoutExt,
    });

    // Wzorce do wyszukiwania numeru lotu (case insensitive)
    const flightPatterns = [
      /z\s+lotu\s+([A-Z0-9]+)/i, // "z lotu PL10023419"
      /z\s+lot\s+([A-Z0-9]+)/i, // "z lot PL10023419"
      /lot\s+([A-Z0-9]+)/i, // "lot PL10023419"
      /lotu\s+([A-Z0-9]+)/i, // "lotu PL10023419"
    ];

    for (const pattern of flightPatterns) {
      const match = nameWithoutExt.match(pattern);
      if (match && match[1]) {
        const flightNumber = match[1].trim().toUpperCase();
        console.log("🔥 ZNALEZIONO NUMER LOTU:", {
          pattern: pattern.toString(),
          match: match[0],
          flightNumber: flightNumber,
        });
        return flightNumber;
      }
    }

    console.log("🔥 NIE ZNALEZIONO NUMERU LOTU w nazwie pliku");
    return null;
  }

  /**
   * Generuje ID dostawy w formacie DST/nr_lotu
   * Jeśli brak numeru lotu, zwraca null - ID będzie wygenerowane po uzupełnieniu formularza
   */
  generateDeliveryId(flightNumber?: string): string | null {
    if (flightNumber) {
      return `DST/${flightNumber}`.toUpperCase();
    }

    // Jeśli brak numeru lotu - NIE generuj automatycznego ID
    // System poczeka na uzupełnienie formularza
    return null;
  }
}

export default new ExcelProcessorService();
