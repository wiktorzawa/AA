/**
 * delivery controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::delivery.delivery",
  ({ strapi }) => ({
    // Nadpisanie domyślnej metody find aby zawsze pobierać relacje
    async find(ctx) {
      // Dodaj domyślne populate jeśli nie zostało określone
      if (!ctx.query.populate) {
        ctx.query.populate = {
          supplier: true,
          products: true,
        };
      }

      // Wywołaj domyślną metodę find
      const { data, meta } = await super.find(ctx);

      return { data, meta };
    },

    // Nadpisanie domyślnej metody findOne aby pobierać wszystkie relacje
    async findOne(ctx) {
      const { id } = ctx.params;

      const entity = await strapi.entityService.findOne(
        "api::delivery.delivery",
        id,
        {
          populate: {
            supplier: true,
            products: true,
          },
        },
      );

      if (!entity) {
        return ctx.notFound("Delivery not found");
      }

      return this.transformResponse(entity);
    },

    // Dodatkowa metoda: pobierz dostawy dostawcy
    async findBySupplier(ctx) {
      const { supplierId } = ctx.params;

      const deliveries = await strapi.entityService.findMany(
        "api::delivery.delivery",
        {
          filters: {
            supplier: {
              id_dostawcy: supplierId,
            },
          },
          populate: {
            supplier: true,
            products: true,
            palettes: true,
          },
          sort: { createdAt: "desc" },
        },
      );

      return this.transformResponse(deliveries);
    },

    // Dodatkowa metoda: pobierz szczegółową analizę dostawy
    async analyze(ctx) {
      try {
        const { id } = ctx.params;

        // Wywołaj serwis, aby wykonał całą ciężką pracę
        const analysisData = await strapi
          .service("api::delivery.delivery")
          .analyzeDelivery(id);

        if (!analysisData) {
          // Kontroler jest odpowiedzialny za odpowiedź HTTP
          return ctx.notFound("Delivery not found");
        }

        // Kontroler po prostu zwraca dane otrzymane z serwisu
        return analysisData;
      } catch (error) {
        strapi.log.error("Error in analyze controller:", error);
        return ctx.internalServerError("An error occurred during analysis.");
      }
    },

    // Nowa metoda: upload pliku dostawy
    async uploadFile(ctx) {
      try {
        // Sprawdzenie czy plik został przesłany
        if (!ctx.request.files || !ctx.request.files.deliveryFile) {
          return ctx.badRequest("Brak pliku dostawy");
        }

        const file = ctx.request.files.deliveryFile;
        const { id_dostawcy, confirmDeliveryNumber, columnMapping } =
          ctx.request.body;

        // Walidacja danych
        if (!id_dostawcy) {
          return ctx.badRequest("ID dostawcy jest wymagane");
        }

        // Wywołanie serwisu do przetworzenia pliku
        const deliveryService = strapi.service("api::delivery.delivery");
        const result = await deliveryService.processUploadedFile({
          file,
          supplierId: id_dostawcy,
          confirmDeliveryNumber,
          columnMapping: columnMapping ? JSON.parse(columnMapping) : null,
        });

        return {
          success: true,
          data: result,
        };
      } catch (error) {
        strapi.log.error("Błąd podczas uploadu pliku:", error);
        return ctx.badRequest(
          error.message || "Błąd podczas przetwarzania pliku",
        );
      }
    },

    // Nowa metoda: podgląd pliku
    async previewFile(ctx) {
      strapi.log.info("=== DELIVERY CONTROLLER - PREVIEW FILE START ===");

      try {
        strapi.log.info("Controller received request", {
          hasFiles: !!ctx.request.files,
          filesKeys: ctx.request.files ? Object.keys(ctx.request.files) : [],
          hasDeliveryFile: !!ctx.request.files?.deliveryFile,
          bodyKeys: ctx.request.body ? Object.keys(ctx.request.body) : [],
          user: ctx.state.user
            ? {
                id: ctx.state.user.id,
                email: ctx.state.user.email,
                role: ctx.state.user.role,
              }
            : "no user",
        });

        if (!ctx.request.files || !ctx.request.files.deliveryFile) {
          strapi.log.error("Controller: No delivery file found", {
            files: ctx.request.files,
            body: ctx.request.body,
          });
          return ctx.badRequest("Brak pliku dostawy");
        }

        const files = ctx.request.files.deliveryFile;
        const file = (Array.isArray(files) ? files[0] : files) as unknown as {
          name: string;
          size: number;
          type: string;
          path: string;
        };
        const { columnMapping } = ctx.request.body;

        strapi.log.info("Controller: File received", {
          fileName: file.name,
          fileSize: file.size,
          fileType: file.type,
          hasColumnMapping: !!columnMapping,
        });

        const deliveryService = strapi.service("api::delivery.delivery");

        strapi.log.info("Controller: Calling delivery service previewFile");

        const preview = await deliveryService.previewFile({
          file,
          columnMapping: columnMapping ? JSON.parse(columnMapping) : null,
        });

        strapi.log.info("Controller: Preview completed successfully", {
          analysisStatus: preview.analysisStatus,
          productsCount: preview.products?.length || 0,
          deliveryNumber: preview.deliveryNumber,
        });

        return {
          success: true,
          data: preview,
        };
      } catch (error) {
        strapi.log.error("Controller: Error during preview", {
          errorMessage: error.message,
          errorStack: error.stack,
          errorName: error.name,
        });
        return ctx.badRequest(
          error.message || "Błąd podczas tworzenia podglądu",
        );
      }
    },

    // Nowa metoda: potwierdź dostawę
    async confirmDelivery(ctx) {
      try {
        if (!ctx.request.files || !ctx.request.files.deliveryFile) {
          return ctx.badRequest("Brak pliku dostawy");
        }

        const file = ctx.request.files.deliveryFile;
        const {
          id_dostawcy,
          confirmedDeliveryNumber,
          confirmedPaletteNumbers,
          productCorrections,
          bypassValidation,
        } = ctx.request.body;

        if (!id_dostawcy) {
          return ctx.badRequest("ID dostawcy jest wymagane");
        }

        const deliveryService = strapi.service("api::delivery.delivery");
        const result = await deliveryService.confirmAndSaveDelivery({
          file,
          supplierId: id_dostawcy,
          confirmationData: {
            confirmedDeliveryNumber,
            confirmedPaletteNumbers: confirmedPaletteNumbers
              ? JSON.parse(confirmedPaletteNumbers)
              : null,
            productCorrections: productCorrections
              ? JSON.parse(productCorrections)
              : null,
            bypassValidation: bypassValidation === "true",
          },
        });

        return {
          success: true,
          message: "Dostawa została pomyślnie potwierdzona i zapisana",
          data: result,
        };
      } catch (error) {
        strapi.log.error("Błąd podczas potwierdzania dostawy:", error);
        return ctx.badRequest(
          error.message || "Błąd podczas potwierdzania dostawy",
        );
      }
    },

    // Nowa metoda: pobierz produkty dostawy
    async getProducts(ctx) {
      const { id } = ctx.params;

      const products = await strapi.entityService.findMany(
        "api::product.product",
        {
          filters: {
            delivery: {
              id,
            },
          },
        },
      );

      return {
        success: true,
        data: products,
      };
    },

    // Nowa metoda: tworzenie finansów po uzupełnieniu danych przez dostawcę
    async createFinances(ctx) {
      try {
        const { deliveryId } = ctx.params;
        const {
          kurs_wymiany, // exchangeRate - WYMAGANE
          procent_wartosci, // marginPercent - WYMAGANE
          stawka_vat, // vatRate - WYMAGANE
          waluta, // currency - WYMAGANE
        } = ctx.request.body;

        strapi.log.info("Creating finances for delivery", {
          deliveryId,
          kurs_wymiany,
          procent_wartosci,
          stawka_vat,
          waluta,
        });

        // Walidacja wymaganych danych
        if (!deliveryId) {
          return ctx.badRequest("ID dostawy jest wymagane");
        }

        if (!kurs_wymiany || kurs_wymiany <= 0) {
          return ctx.badRequest(
            "Kurs wymiany jest wymagany i musi być większy od 0",
          );
        }

        if (!procent_wartosci || procent_wartosci <= 0) {
          return ctx.badRequest(
            "Procent wartości (marża) jest wymagany i musi być większy od 0",
          );
        }

        if (stawka_vat === undefined || stawka_vat === null || stawka_vat < 0) {
          return ctx.badRequest(
            "Stawka VAT jest wymagana i nie może być ujemna",
          );
        }

        if (!waluta) {
          return ctx.badRequest("Waluta jest wymagana");
        }

        // Sprawdź czy dostawa istnieje
        const delivery = await strapi.entityService.findOne(
          "api::delivery.delivery",
          deliveryId,
          {
            populate: {
              products: true,
            },
          },
        );

        if (!delivery) {
          return ctx.notFound("Dostawa nie została znaleziona");
        }

        // Sprawdź czy finanse już istnieją
        const existingFinance = await strapi.entityService.findMany(
          "api::delivery-finance.delivery-finance",
          {
            filters: {
              id_dostawy: delivery.id_dostawy,
            },
            limit: 1,
          },
        );

        if (existingFinance && existingFinance.length > 0) {
          return ctx.badRequest("Finanse dla tej dostawy już istnieją");
        }

        // Utwórz finanse z danymi od dostawcy
        const finance = await strapi
          .service("api::delivery-finance.delivery-finance")
          .createWithCalculations(delivery.id, (delivery as any).products, {
            exchangeRate: parseFloat(kurs_wymiany),
            marginPercent: parseFloat(procent_wartosci),
            vatRate: parseFloat(stawka_vat),
            currency: waluta,
          });

        strapi.log.info("Finances created successfully", {
          deliveryId: delivery.id_dostawy,
          financeId: finance.id,
        });

        return {
          success: true,
          message: "Dane finansowe zostały utworzone pomyślnie",
          data: {
            delivery: {
              id_dostawy: delivery.id_dostawy,
              nazwa_pliku: delivery.nazwa_pliku,
            },
            finance: {
              id: finance.id,
              suma_produktow: finance.suma_produktow,
              wartosc_produktow_spec: finance.wartosc_produktow_spec,
              koszt_pln_brutto: finance.koszt_pln_brutto,
              koszt_pln_netto: finance.koszt_pln_netto,
              kurs_wymiany: finance.kurs_wymiany,
              procent_wartosci: finance.procent_wartosci,
              stawka_vat: finance.stawka_vat,
              waluta: finance.waluta,
            },
          },
        };
      } catch (error) {
        strapi.log.error("Błąd podczas tworzenia finansów:", error);
        return ctx.badRequest(
          error.message || "Błąd podczas tworzenia danych finansowych",
        );
      }
    },
  }),
);
