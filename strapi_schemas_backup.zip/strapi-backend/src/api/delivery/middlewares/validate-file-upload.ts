import { errors } from "@strapi/utils";

const { ApplicationError } = errors;

// Definiujemy typ dla pliku w Strapi
interface StrapiFile {
  name?: string;
  originalName?: string;
  filename?: string;
  originalFilename?: string;
  type?: string;
  mimetype?: string;
  size?: number;
  path?: string;
  filepath?: string;
}

export default () => {
  return async (ctx, next) => {
    console.log("=== VALIDATE FILE UPLOAD START ===");

    try {
      // Debug: loguj całą strukturę żądania
      console.log(
        "Request details:",
        JSON.stringify(
          {
            method: ctx.request.method,
            url: ctx.request.url,
            headers: {
              contentType: ctx.request.headers["content-type"],
              authorization: ctx.request.headers.authorization
                ? "present"
                : "missing",
              contentLength: ctx.request.headers["content-length"],
            },
            hasFiles: !!ctx.request.files,
            hasBody: !!ctx.request.body,
          },
          null,
          2,
        ),
      );

      // Loguj szczegóły files
      if (ctx.request.files) {
        console.log(
          "Files structure:",
          JSON.stringify(
            {
              filesKeys: Object.keys(ctx.request.files),
              filesCount: Object.keys(ctx.request.files).length,
              allFiles: Object.entries(ctx.request.files).map(([key, file]) => {
                const typedFile = file as StrapiFile | StrapiFile[];
                return {
                  key,
                  isArray: Array.isArray(typedFile),
                  fileDetails: Array.isArray(typedFile)
                    ? typedFile.map((f) => ({
                        name: f.name,
                        originalName: f.originalName,
                        filename: f.filename,
                        originalFilename: f.originalFilename,
                        type: f.type,
                        mimetype: f.mimetype,
                        size: f.size,
                      }))
                    : {
                        name: typedFile.name,
                        originalName: typedFile.originalName,
                        filename: typedFile.filename,
                        originalFilename: typedFile.originalFilename,
                        type: typedFile.type,
                        mimetype: typedFile.mimetype,
                        size: typedFile.size,
                      },
                };
              }),
            },
            null,
            2,
          ),
        );
      } else {
        console.log("ERROR: No files in request");
      }

      // Loguj body
      if (ctx.request.body) {
        console.log(
          "Request body:",
          JSON.stringify(
            {
              bodyKeys: Object.keys(ctx.request.body),
              bodyContent: ctx.request.body,
            },
            null,
            2,
          ),
        );
      }

      // Sprawdź czy plik został przesłany
      if (!ctx.request.files || !ctx.request.files.deliveryFile) {
        console.log(
          "ERROR: No deliveryFile found in request:",
          JSON.stringify(
            {
              availableFileKeys: ctx.request.files
                ? Object.keys(ctx.request.files)
                : [],
              hasFiles: !!ctx.request.files,
            },
            null,
            2,
          ),
        );
        throw new ApplicationError("Brak pliku do przesłania", 400);
      }

      const file = ctx.request.files.deliveryFile as StrapiFile | StrapiFile[];

      // Sprawdź czy to array czy single file
      const fileToValidate = Array.isArray(file) ? file[0] : file;

      // Debug: loguj wszystkie właściwości pliku
      console.log(
        "Complete file object:",
        JSON.stringify(
          {
            isArray: Array.isArray(file),
            fileObject: fileToValidate,
            allKeys: Object.keys(fileToValidate),
            allValues: Object.entries(fileToValidate).reduce(
              (acc, [key, value]) => {
                acc[key] = typeof value === "object" ? "[object]" : value;
                return acc;
              },
              {} as any,
            ),
          },
          null,
          2,
        ),
      );

      // Walidacja typu pliku
      const allowedMimeTypes = [
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
        "application/vnd.ms-excel", // .xls
        "application/vnd.ms-excel.sheet.macroEnabled.12", // .xlsm
        "application/vnd.ms-excel.sheet.macroenabled.12", // .xlsm (alternative)
        "application/zip", // .xlsm może być wykrywany jako ZIP
        "text/csv", // .csv
        "application/csv", // .csv (alternative)
      ];

      const allowedExtensions = [".xlsx", ".xls", ".xlsm", ".csv"];

      // Użyj różnych właściwości nazwy pliku
      const fileName =
        fileToValidate.name ||
        fileToValidate.originalName ||
        fileToValidate.filename ||
        (fileToValidate as any).originalFilename;

      console.log(
        "File name analysis:",
        JSON.stringify(
          {
            name: fileToValidate.name,
            originalName: fileToValidate.originalName,
            filename: fileToValidate.filename,
            originalFilename: (fileToValidate as any).originalFilename,
            finalFileName: fileName,
            nameType: typeof fileName,
            nameLength: fileName ? fileName.length : 0,
          },
          null,
          2,
        ),
      );

      if (!fileName || typeof fileName !== "string") {
        console.log(
          "ERROR: Invalid file name - detailed analysis:",
          JSON.stringify(
            {
              name: fileToValidate.name,
              originalName: fileToValidate.originalName,
              filename: fileToValidate.filename,
              nameType: typeof fileName,
              nameValue: fileName,
              isNull: fileName === null,
              isUndefined: fileName === undefined,
              isEmpty: fileName === "",
            },
            null,
            2,
          ),
        );
        throw new ApplicationError("Nazwa pliku jest nieprawidłowa", 400);
      }

      const fileExtension = fileName
        .toLowerCase()
        .slice(fileName.lastIndexOf("."));

      const mimeType = fileToValidate.type || fileToValidate.mimetype;
      const isValidMimeType = mimeType && allowedMimeTypes.includes(mimeType);
      const isValidExtension = allowedExtensions.includes(fileExtension);

      console.log(
        "File validation check:",
        JSON.stringify(
          {
            fileName,
            fileExtension,
            mimeType,
            isValidMimeType,
            isValidExtension,
            allowedMimeTypes,
            allowedExtensions,
          },
          null,
          2,
        ),
      );

      // Dodatkowa obsługa plików .xls
      if (fileExtension === ".xls" && !isValidMimeType) {
        console.log("XLS file detected - allowing based on extension");
        // Pozwól na pliki .xls nawet jeśli mime type nie jest rozpoznany
      } else if (!isValidMimeType && !isValidExtension) {
        console.log(
          "ERROR: File validation failed:",
          JSON.stringify(
            {
              fileName,
              fileExtension,
              mimeType,
              reason: "Neither MIME type nor extension is valid",
            },
            null,
            2,
          ),
        );
        throw new ApplicationError(
          `Nieprawidłowy format pliku. Obsługiwane formaty: .xlsx, .xls, .xlsm, .csv. Wykryto: ${fileExtension} (${mimeType})`,
          400,
        );
      }

      // Walidacja rozmiaru pliku (10MB limit)
      const maxSize = 10 * 1024 * 1024; // 10MB
      const fileSize = fileToValidate.size;

      console.log(
        "File size check:",
        JSON.stringify(
          {
            fileSize,
            maxSize,
            isValidSize:
              fileSize && typeof fileSize === "number" && fileSize <= maxSize,
            sizeInMB: fileSize
              ? (fileSize / 1024 / 1024).toFixed(2)
              : "unknown",
          },
          null,
          2,
        ),
      );

      if (!fileSize || typeof fileSize !== "number" || fileSize > maxSize) {
        throw new ApplicationError(
          `Plik jest zbyt duży lub nieprawidłowy. Maksymalny rozmiar to 10MB. Rozmiar pliku: ${fileSize ? (fileSize / 1024 / 1024).toFixed(2) + "MB" : "nieznany"}`,
          413,
        );
      }

      // Walidacja nazwy pliku
      if (!fileName || fileName.trim() === "") {
        throw new ApplicationError("Nazwa pliku nie może być pusta", 400);
      }

      // Sprawdź czy nazwa pliku zawiera niebezpieczne znaki
      const dangerousChars = /[<>:"/\\|?*\x00-\x1f]/;
      if (dangerousChars.test(fileName)) {
        console.log(
          "WARNING: File name contains dangerous characters:",
          JSON.stringify(
            {
              fileName,
              dangerousChars: fileName.match(dangerousChars),
            },
            null,
            2,
          ),
        );
        throw new ApplicationError(
          "Nazwa pliku zawiera niedozwolone znaki",
          400,
        );
      }

      console.log(
        "File validation passed:",
        JSON.stringify(
          {
            fileName: fileName || "unknown",
            fileSize: fileSize || 0,
            sizeInMB: fileSize ? (fileSize / 1024 / 1024).toFixed(2) : "0",
            mimeType: mimeType || "unknown",
            extension: fileExtension,
          },
          null,
          2,
        ),
      );

      console.log("=== VALIDATE FILE UPLOAD END - SUCCESS ===");

      await next();
    } catch (error) {
      console.log(
        "=== VALIDATE FILE UPLOAD END - ERROR ===",
        JSON.stringify(
          {
            errorMessage: error.message,
            errorStack: error.stack,
            errorName: error.name,
            errorType: typeof error,
          },
          null,
          2,
        ),
      );
      throw error;
    }
  };
};
