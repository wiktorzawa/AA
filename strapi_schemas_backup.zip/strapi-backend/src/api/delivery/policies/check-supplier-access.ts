/**
 * Policy do sprawdzania czy użytkownik ma dostęp do dostaw danego dostawcy
 * Używane dla endpointu /deliveries/supplier/:supplierId
 */

export default async (policyContext, config, { strapi }) => {
  const { user } = policyContext.state;
  const { supplierId } = policyContext.params;

  if (!user) {
    return false;
  }

  // Admin i staff mogą widzieć wszystkie dostawy
  if (user.role?.name === "Admin" || user.role?.name === "Staff") {
    return true;
  }

  // Sprawdź czy użytkownik jest dostawcą
  if (user.role?.name === "Supplier" || user.role?.name === "Dostawca") {
    // Znajdź dostawcę powiązanego z tym użytkownikiem
    const supplier = await strapi.entityService.findMany(
      "api::supplier.supplier",
      {
        filters: {
          email: user.email,
        },
        limit: 1,
      },
    );

    if (!supplier || supplier.length === 0) {
      strapi.log.warn("Supplier not found for user", {
        userId: user.id,
        email: user.email,
      });
      return false;
    }

    // Sprawdź czy ID dostawcy się zgadza
    if (supplier[0].id_dostawcy !== supplierId) {
      strapi.log.warn("Supplier access denied", {
        requestedSupplierId: supplierId,
        userSupplierId: supplier[0].id_dostawcy,
      });
      return false;
    }

    return true;
  }

  // Domyślnie odmów dostępu
  return false;
};
