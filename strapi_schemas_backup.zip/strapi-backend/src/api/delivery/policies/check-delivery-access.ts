/**
 * Policy do sprawdzania czy użytkownik ma dostęp do konkretnej dostawy
 * Używane dla endpointów pracujących na pojedynczej dostawie
 */

export default async (policyContext, config, { strapi }) => {
  const { user } = policyContext.state;
  const { id } = policyContext.params;

  if (!user) {
    return false;
  }

  // Admin i staff mogą widzieć wszystkie dostawy
  if (user.role?.name === "Admin" || user.role?.name === "Staff") {
    return true;
  }

  // Sprawdź czy użytkownik jest dostawcą
  if (user.role?.name === "Supplier" || user.role?.name === "Dostawca") {
    // Znajdź dostawcę powiązanego z tym użytkownikiem
    const supplier = await strapi.entityService.findMany(
      "api::supplier.supplier",
      {
        filters: {
          email: user.email,
        },
        limit: 1,
      },
    );

    if (!supplier || supplier.length === 0) {
      strapi.log.warn("Supplier not found for user", {
        userId: user.id,
        email: user.email,
      });
      return false;
    }

    // Znajdź dostawę
    const delivery = await strapi.entityService.findOne(
      "api::delivery.delivery",
      id,
      {
        fields: ["id_dostawcy"],
      },
    );

    if (!delivery) {
      strapi.log.warn("Delivery not found", { deliveryId: id });
      return false;
    }

    // Sprawdź czy dostawa należy do tego dostawcy
    if (delivery.id_dostawcy !== supplier[0].id_dostawcy) {
      strapi.log.warn("Delivery access denied", {
        deliveryId: id,
        deliverySupplierId: delivery.id_dostawcy,
        userSupplierId: supplier[0].id_dostawcy,
      });
      return false;
    }

    return true;
  }

  // Domyślnie odmów dostępu
  return false;
};
