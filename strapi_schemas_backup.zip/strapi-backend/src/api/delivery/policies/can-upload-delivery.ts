/**
 * Policy do sprawdzania czy użytkownik może przesyłać nowe dostawy
 * Używa standardowego systemu Strapi users-permissions
 */

export default async (policyContext, config, { strapi }) => {
  const { user } = policyContext.state;
  const { id_dostawcy } = policyContext.request.body;

  // Dodaj szczegółowe logowanie
  strapi.log.info("can-upload-delivery policy started", {
    hasUser: !!user,
    userId: user?.id,
    userEmail: user?.email,
    userRole: user?.role?.name,
    requestedSupplierId: id_dostawcy,
  });

  if (!user) {
    strapi.log.warn("can-upload-delivery: No user in context");
    return false;
  }

  // Admin i staff mogą przesyłać dostawy dla wszystkich dostawców
  if (user.role?.name === "Admin" || user.role?.name === "Staff") {
    strapi.log.info("can-upload-delivery: Admin/Staff user detected", {
      role: user.role?.name,
      id_dostawcy,
    });

    // Sprawdź czy podano ID dostawcy
    if (!id_dostawcy) {
      strapi.log.error("Missing id_dostawcy for admin/staff upload");
      policyContext.throw(400, "ID dostawcy jest wymagane");
    }
    return true;
  }

  // Sprawdź czy użytkownik jest dostawcą
  if (user.role?.name === "Supplier" || user.role?.name === "Dostawca") {
    strapi.log.info("can-upload-delivery: Supplier user detected", {
      role: user.role?.name,
      email: user.email,
    });

    // Znajdź dostawcę powiązanego z tym użytkownikiem po emailu
    const supplier = await strapi.entityService.findMany(
      "api::supplier.supplier",
      {
        filters: {
          email: user.email,
        },
        limit: 1,
      },
    );

    strapi.log.info("can-upload-delivery: Supplier search result", {
      foundSuppliers: supplier?.length || 0,
      supplierData: supplier?.[0]
        ? {
            id_dostawcy: supplier[0].id_dostawcy,
            email: supplier[0].email,
            nazwa: supplier[0].nazwa,
          }
        : null,
    });

    if (!supplier || supplier.length === 0) {
      strapi.log.warn("Supplier not found for user", {
        userId: user.id,
        email: user.email,
      });
      return false;
    }

    // Dostawca może przesyłać tylko swoje dostawy
    if (id_dostawcy && id_dostawcy !== supplier[0].id_dostawcy) {
      strapi.log.warn("Supplier trying to upload for different supplier", {
        requestedSupplierId: id_dostawcy,
        userSupplierId: supplier[0].id_dostawcy,
      });
      return false;
    }

    // Jeśli nie podano ID dostawcy, ustaw je automatycznie
    if (!id_dostawcy) {
      strapi.log.info("can-upload-delivery: Auto-setting supplier ID", {
        supplierId: supplier[0].id_dostawcy,
      });
      policyContext.request.body.id_dostawcy = supplier[0].id_dostawcy;
    }

    strapi.log.info("can-upload-delivery: Supplier access granted");
    return true;
  }

  // Domyślnie odmów dostępu
  strapi.log.warn("can-upload-delivery: Access denied - unknown role", {
    userRole: user.role?.name,
    userId: user.id,
    email: user.email,
  });
  return false;
};
