import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::staff-member.staff-member",
  ({ strapi }) => ({
    /**
     * Generuje unikalny ID pracownika
     */
    async generateStaffId(role: "admin" | "staff"): Promise<string> {
      const prefix = role === "admin" ? "ADM" : "STF";
      const existing = await strapi.entityService.findMany(
        "api::staff-member.staff-member",
        {
          filters: { id_pracownika: { $startsWith: prefix } },
          sort: { id_pracownika: "desc" },
          limit: 1,
        },
      );

      let sequence = 1;
      if (existing && existing.length > 0) {
        const lastId = existing[0].id_pracownika;
        const lastNumber = parseInt(lastId.split("-")[1]);
        sequence = lastNumber + 1;
      }

      return `${prefix}-${sequence.toString().padStart(4, "0")}`;
    },

    /**
     * Tworzy nowego pracownika (profil) oraz powiązane z nim konto użytkownika
     */
    async createWithUser(data: {
      imie: string;
      nazwisko: string;
      adres_email: string;
      telefon: string;
      rola: "admin" | "staff";
      password?: string;
    }) {
      const staffId = await this.generateStaffId(data.rola);

      const userService = strapi.service("plugin::users-permissions.user");
      const roleService = strapi.service("plugin::users-permissions.role");

      const existingUser = await userService.fetch({ email: data.adres_email });
      if (existingUser) {
        throw new Error(
          `Użytkownik z emailem ${data.adres_email} już istnieje.`,
        );
      }

      const userRole = await roleService.findOne({ name: data.rola });
      if (!userRole) {
        throw new Error(`Rola '${data.rola}' nie została znaleziona.`);
      }

      const newUser = await userService.add({
        username: data.adres_email,
        email: data.adres_email,
        password: data.password || Math.random().toString(36).slice(-12),
        role: userRole.id,
        provider: "local",
        confirmed: true,
      });

      const staffProfile = await strapi.entityService.create(
        "api::staff-member.staff-member",
        {
          data: {
            id_pracownika: staffId,
            imie: data.imie,
            nazwisko: data.nazwisko,
            adres_email: data.adres_email,
            telefon: data.telefon,
            rola: data.rola,
            data_zatrudnienia: new Date(),
            user: newUser.id,
          },
        },
      );

      return staffProfile;
    },

    /**
     * Zwolnij pracownika (ustaw datę zwolnienia i zablokuj konto)
     */
    async terminateEmployee(staffProfileId: number, terminationDate?: Date) {
      const staff = (await strapi.entityService.findOne(
        "api::staff-member.staff-member",
        staffProfileId,
        { populate: ["user"] },
      )) as any;
      if (!staff || !staff.user) {
        throw new Error(
          "Pracownik lub powiązane konto użytkownika nie znalezione",
        );
      }

      await strapi
        .service("plugin::users-permissions.user")
        .edit(staff.user.id, { blocked: true });

      return await strapi.entityService.update(
        "api::staff-member.staff-member",
        staffProfileId,
        {
          data: {
            data_zwolnienia: terminationDate || new Date(),
          },
        },
      );
    },

    /**
     * Przywróć pracownika (usuń datę zwolnienia i odblokuj konto)
     */
    async reactivateEmployee(staffProfileId: number) {
      const staff = (await strapi.entityService.findOne(
        "api::staff-member.staff-member",
        staffProfileId,
        { populate: ["user"] },
      )) as any;
      if (!staff || !staff.user) {
        throw new Error(
          "Pracownik lub powiązane konto użytkownika nie znalezione",
        );
      }

      await strapi
        .service("plugin::users-permissions.user")
        .edit(staff.user.id, { blocked: false });

      return await strapi.entityService.update(
        "api::staff-member.staff-member",
        staffProfileId,
        {
          data: {
            data_zwolnienia: null,
          },
        },
      );
    },
  }),
);
