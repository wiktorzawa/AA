import { factories } from "@strapi/strapi";

// Definicja typu dla produktu na wejściu funkcji kalkulujących
interface ProductInput {
  ilosc: number;
  cena_produktu_spec: number;
}

export default factories.createCoreService(
  "api::delivery-finance.delivery-finance",
  ({ strapi }) => ({
    /**
     * Tworzy rekord finansowy dla dostawy z automatycznymi kalkulacjami
     */
    async createForDelivery(
      deliveryId: string,
      financeData: {
        suma_produktow: number;
        wartosc_produktow_spec: number;
        procent_wartosci: number; // WYMAGANE - podaje dostawca
        stawka_vat: number; // WYMAGANE - podaje dostawca
        waluta: string; // WYMAGANE - waluta z Unit retail
        kurs_wymiany: number; // WYMAGANE - podaje dostawca
      },
    ) {
      // Sprawdź czy finanse dla tej dostawy już istnieją
      const existing = await strapi.entityService.findMany(
        "api::delivery-finance.delivery-finance",
        {
          filters: {
            id_dostawy: deliveryId,
          },
          limit: 1,
        },
      );

      if (existing && existing.length > 0) {
        throw new Error(`Finanse dla dostawy ${deliveryId} już istnieją`);
      }

      // Walidacja wymaganych danych
      if (!financeData.procent_wartosci || financeData.procent_wartosci <= 0) {
        throw new Error(
          "Procent wartości (marża) jest wymagany i musi być większy od 0",
        );
      }

      if (!financeData.stawka_vat || financeData.stawka_vat < 0) {
        throw new Error("Stawka VAT jest wymagana i nie może być ujemna");
      }

      if (!financeData.kurs_wymiany || financeData.kurs_wymiany <= 0) {
        throw new Error("Kurs wymiany jest wymagany i musi być większy od 0");
      }

      if (!financeData.waluta) {
        throw new Error("Waluta jest wymagana");
      }

      // Kalkulacje zgodne ze starą logiką:
      // Wartość ze specyfikacji (suma PLN) = wartosc_produktow_spec * kurs_wymiany
      // Koszt netto = Wartość ze specyfikacji (suma PLN) * procent_wartosci
      // Koszt brutto = Koszt netto * (1 + stawka_vat)
      const wartosc_brutto =
        financeData.wartosc_produktow_spec * (1 + financeData.stawka_vat);
      const koszt_pln_netto =
        financeData.wartosc_produktow_spec *
        financeData.kurs_wymiany *
        financeData.procent_wartosci;
      const koszt_pln_brutto = koszt_pln_netto * (1 + financeData.stawka_vat);

      return strapi.entityService.create(
        "api::delivery-finance.delivery-finance",
        {
          data: {
            id_dostawy: deliveryId,
            suma_produktow: financeData.suma_produktow,
            wartosc_produktow_spec: financeData.wartosc_produktow_spec,
            stawka_vat: financeData.stawka_vat,
            procent_wartosci: financeData.procent_wartosci,
            wartosc_brutto: wartosc_brutto,
            koszt_pln_brutto: koszt_pln_brutto,
            koszt_pln_netto: koszt_pln_netto,
            waluta: financeData.waluta as "PLN" | "EUR" | "USD" | "GBP",
            kurs_wymiany: financeData.kurs_wymiany,
            delivery: deliveryId,
          },
        },
      );
    },

    /**
     * Oblicza dane finansowe na podstawie produktów dostawy
     */
    calculateFinanceFromProducts(
      products: ProductInput[],
      exchangeRate: number, // WYMAGANE - kurs wymiany
      marginPercent: number, // WYMAGANE - procent wartości (marża)
      vatRate: number, // WYMAGANE - stawka VAT
      currency: string, // WYMAGANE - waluta
    ) {
      // Walidacja parametrów
      if (!exchangeRate || exchangeRate <= 0) {
        throw new Error("Kurs wymiany jest wymagany i musi być większy od 0");
      }

      if (!marginPercent || marginPercent <= 0) {
        throw new Error(
          "Procent wartości (marża) jest wymagany i musi być większy od 0",
        );
      }

      if (vatRate < 0) {
        throw new Error("Stawka VAT nie może być ujemna");
      }

      if (!currency) {
        throw new Error("Waluta jest wymagana");
      }

      let suma_produktow = 0;
      let wartosc_produktow_spec = 0;

      products.forEach((product) => {
        suma_produktow += product.ilosc || 0;
        wartosc_produktow_spec +=
          (product.cena_produktu_spec || 0) * (product.ilosc || 0);
      });

      const wartosc_brutto = wartosc_produktow_spec * (1 + vatRate);
      const koszt_pln_netto =
        wartosc_produktow_spec * exchangeRate * marginPercent;
      const koszt_pln_brutto = koszt_pln_netto * (1 + vatRate);

      return {
        suma_produktow,
        wartosc_produktow_spec,
        stawka_vat: vatRate,
        procent_wartosci: marginPercent,
        wartosc_brutto,
        koszt_pln_brutto,
        koszt_pln_netto,
        waluta: currency,
        kurs_wymiany: exchangeRate,
      };
    },

    /**
     * Tworzy kompletny rekord finansowy z automatycznymi kalkulacjami na podstawie produktów
     * WSZYSTKIE PARAMETRY SĄ WYMAGANE - PODAJE DOSTAWCA
     */
    async createWithCalculations(
      deliveryId: string,
      products: ProductInput[],
      financeParams: {
        exchangeRate: number; // kurs_wymiany - WYMAGANE
        marginPercent: number; // procent_wartosci - WYMAGANE
        vatRate: number; // stawka_vat - WYMAGANE
        currency: string; // waluta - WYMAGANE
      },
    ) {
      // Walidacja że wszystkie parametry są podane
      if (!financeParams.exchangeRate) {
        throw new Error("Kurs wymiany jest wymagany");
      }

      if (!financeParams.marginPercent) {
        throw new Error("Procent wartości (marża) jest wymagany");
      }

      if (
        financeParams.vatRate === undefined ||
        financeParams.vatRate === null
      ) {
        throw new Error("Stawka VAT jest wymagana");
      }

      if (!financeParams.currency) {
        throw new Error("Waluta jest wymagana");
      }

      const financeData = this.calculateFinanceFromProducts(
        products,
        financeParams.exchangeRate,
        financeParams.marginPercent,
        financeParams.vatRate,
        financeParams.currency,
      );

      return this.createForDelivery(deliveryId, financeData);
    },

    /**
     * Aktualizuje dane finansowe (np. po zmianie kursu lub marży)
     */
    async updateFinanceCalculations(
      financeId: string,
      updates: {
        kurs_wymiany?: number;
        procent_wartosci?: number;
        stawka_vat?: number;
      },
    ) {
      const finance = await strapi.entityService.findOne(
        "api::delivery-finance.delivery-finance",
        financeId,
      );

      if (!finance) {
        throw new Error("Rekord finansowy nie znaleziony");
      }

      // Użyj nowych wartości lub zachowaj stare
      const kurs = updates.kurs_wymiany || finance.kurs_wymiany;
      const procent = updates.procent_wartosci || finance.procent_wartosci;
      const vat = updates.stawka_vat || finance.stawka_vat;

      // Walidacja
      if (kurs <= 0) {
        throw new Error("Kurs wymiany musi być większy od 0");
      }

      if (procent <= 0) {
        throw new Error("Procent wartości musi być większy od 0");
      }

      if (vat < 0) {
        throw new Error("Stawka VAT nie może być ujemna");
      }

      // Przelicz na podstawie nowych wartości
      const wartosc_brutto = finance.wartosc_produktow_spec * (1 + vat);
      const koszt_pln_netto = finance.wartosc_produktow_spec * kurs * procent;
      const koszt_pln_brutto = koszt_pln_netto * (1 + vat);

      return strapi.entityService.update(
        "api::delivery-finance.delivery-finance",
        financeId,
        {
          data: {
            kurs_wymiany: kurs,
            procent_wartosci: procent,
            stawka_vat: vat,
            wartosc_brutto,
            koszt_pln_brutto,
            koszt_pln_netto,
          },
        },
      );
    },
  }),
);
