export default {
  routes: [
    // Standardowe CRUD routes
    {
      method: "GET",
      path: "/delivery-finances",
      handler: "delivery-finance.find",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "GET",
      path: "/delivery-finances/:id",
      handler: "delivery-finance.findOne",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "POST",
      path: "/delivery-finances",
      handler: "delivery-finance.create",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "PUT",
      path: "/delivery-finances/:id",
      handler: "delivery-finance.update",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "DELETE",
      path: "/delivery-finances/:id",
      handler: "delivery-finance.delete",
      config: {
        policies: [],
        middlewares: [],
      },
    },

    // Niestandardowe routes
    {
      method: "POST",
      path: "/delivery-finances/delivery/:deliveryId",
      handler: "delivery-finance.createForDelivery",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "POST",
      path: "/delivery-finances/delivery/:deliveryId/calculate",
      handler: "delivery-finance.createWithCalculations",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "PUT",
      path: "/delivery-finances/:id/calculations",
      handler: "delivery-finance.updateCalculations",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "GET",
      path: "/delivery-finances/delivery/:deliveryId",
      handler: "delivery-finance.getByDelivery",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "POST",
      path: "/delivery-finances/calculate-preview",
      handler: "delivery-finance.calculatePreview",
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};
