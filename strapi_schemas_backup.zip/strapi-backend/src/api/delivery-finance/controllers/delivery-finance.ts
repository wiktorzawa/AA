import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::delivery-finance.delivery-finance",
  ({ strapi }) => ({
    /**
     * Tworzy dane finansowe dla dostawy
     */
    async createForDelivery(ctx) {
      try {
        const { deliveryId } = ctx.params;
        const financeData = ctx.request.body;

        if (!deliveryId) {
          return ctx.badRequest("ID dostawy jest wymagany");
        }

        // Sprawdź czy dostawa istnieje
        const delivery = await strapi.entityService.findOne(
          "api::delivery.delivery",
          deliveryId,
        );

        if (!delivery) {
          return ctx.notFound("Dostawa nie została znaleziona");
        }

        const finance = await strapi
          .service("api::delivery-finance.delivery-finance")
          .createForDelivery(deliveryId, financeData);

        ctx.send({
          success: true,
          data: finance,
          message: "Dane finansowe zostały utworzone pomyślnie",
        });
      } catch (error) {
        strapi.log.error("Błąd tworzenia danych finansowych:", error);
        ctx.throw(500, error.message || "Błąd serwera");
      }
    },

    /**
     * Tworzy dane finansowe z automatycznymi kalkulacjami na podstawie produktów
     */
    async createWithCalculations(ctx) {
      try {
        const { deliveryId } = ctx.params;
        const { products, options = {} } = ctx.request.body;

        if (!deliveryId) {
          return ctx.badRequest("ID dostawy jest wymagany");
        }

        if (!products || !Array.isArray(products)) {
          return ctx.badRequest("Lista produktów jest wymagana");
        }

        const finance = await strapi
          .service("api::delivery-finance.delivery-finance")
          .createWithCalculations(deliveryId, products, options);

        ctx.send({
          success: true,
          data: finance,
          message: "Dane finansowe zostały utworzone z kalkulacjami",
        });
      } catch (error) {
        strapi.log.error(
          "Błąd tworzenia danych finansowych z kalkulacjami:",
          error,
        );
        ctx.throw(500, error.message || "Błąd serwera");
      }
    },

    /**
     * Aktualizuje kalkulacje finansowe
     */
    async updateCalculations(ctx) {
      try {
        const { id } = ctx.params;
        const updates = ctx.request.body;

        if (!id) {
          return ctx.badRequest("ID rekordu finansowego jest wymagany");
        }

        const finance = await strapi
          .service("api::delivery-finance.delivery-finance")
          .updateFinanceCalculations(id, updates);

        ctx.send({
          success: true,
          data: finance,
          message: "Kalkulacje zostały zaktualizowane",
        });
      } catch (error) {
        strapi.log.error("Błąd aktualizacji kalkulacji:", error);
        ctx.throw(500, error.message || "Błąd serwera");
      }
    },

    /**
     * Pobiera dane finansowe dla dostawy
     */
    async getByDelivery(ctx) {
      try {
        const { deliveryId } = ctx.params;

        if (!deliveryId) {
          return ctx.badRequest("ID dostawy jest wymagany");
        }

        const finance = await strapi.entityService.findMany(
          "api::delivery-finance.delivery-finance",
          {
            filters: {
              id_dostawy: deliveryId,
            },
            populate: {
              delivery: true,
            },
          },
        );

        if (!finance || finance.length === 0) {
          return ctx.notFound(
            "Dane finansowe dla tej dostawy nie zostały znalezione",
          );
        }

        ctx.send({
          success: true,
          data: finance[0],
        });
      } catch (error) {
        strapi.log.error("Błąd pobierania danych finansowych:", error);
        ctx.throw(500, error.message || "Błąd serwera");
      }
    },

    /**
     * Oblicza podgląd danych finansowych bez zapisywania
     */
    async calculatePreview(ctx) {
      try {
        const { products, options = {} } = ctx.request.body;

        if (!products || !Array.isArray(products)) {
          return ctx.badRequest("Lista produktów jest wymagana");
        }

        const financeData = strapi
          .service("api::delivery-finance.delivery-finance")
          .calculateFinanceFromProducts(
            products,
            options.exchangeRate || 4.5,
            options.marginPercent || 0.18,
            options.vatRate || 0.23,
          );

        ctx.send({
          success: true,
          data: financeData,
          message: "Podgląd kalkulacji finansowych",
        });
      } catch (error) {
        strapi.log.error("Błąd kalkulacji podglądu:", error);
        ctx.throw(500, error.message || "Błąd serwera");
      }
    },
  }),
);
