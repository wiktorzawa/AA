import { factories } from "@strapi/strapi";

// Typ dla danych wejściowych nowej faktury
interface InvoiceInput {
  numer_faktury: string;
  data_faktury: string; // lub Date
  kwota_netto: number;
  kwota_brutto: number;
  kwota_vat: number;
  waluta: "PLN" | "EUR" | "USD" | "GBP";
  status_platnosci?:
    | "nieoplacona"
    | "czesciowo_oplacona"
    | "oplacona"
    | "anulowana";
  // Dodaj inne wymagane pola
}

export default factories.createCoreService(
  "api::invoice.invoice",
  ({ strapi }) => ({
    /**
     * Generuje unikalny ID faktury
     */
    generateInvoiceId(): string {
      const timestamp = Date.now().toString(36);
      const random = Math.random().toString(36).substring(2, 4);
      return `INV-${timestamp}-${random}`.toUpperCase();
    },

    /**
     * Tworzy nową fakturę z automatycznym ID
     */
    async createWithAutoId(data: InvoiceInput) {
      const invoiceId = this.generateInvoiceId();

      // Sprawdź czy ID już istnieje (bardzo mało prawdopodobne)
      const existing = await strapi.entityService.findMany(
        "api::invoice.invoice",
        {
          filters: { id_faktury: invoiceId },
          limit: 1,
        },
      );

      if (existing && existing.length > 0) {
        // Jeśli istnieje, spróbuj ponownie
        return this.createWithAutoId(data);
      }

      return strapi.entityService.create("api::invoice.invoice", {
        data: {
          id_faktury: invoiceId,
          status_platnosci: "nieoplacona", // Poprawiona domyślna wartość
          ...data,
        },
      });
    },

    /**
     * Generuje numer faktury na podstawie daty i sekwencji
     */
    generateInvoiceNumber(supplierId: string): string {
      const date = new Date();
      const year = date.getFullYear();
      const month = (date.getMonth() + 1).toString().padStart(2, "0");
      const timestamp = Date.now().toString().slice(-6); // Ostatnie 6 cyfr

      return `${supplierId}/INV/${year}/${month}/${timestamp}`;
    },
  }),
);
